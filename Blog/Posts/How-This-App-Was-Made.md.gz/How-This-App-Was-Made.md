﻿---
Title: How this Blazor app was made
Category: Blazor
Description: A detailed walkthrough on how this app was made from coding to deployment. 
ImageUrl: /media/posts/how-this-app-was-made.png
Url: how-this-app-was-made
Date: 2020-09-30
DateUpdated: 2020-09-30
Tags: 
   - C#
   - Blazor-WebAssembly
   - Netlify
   - Azure-Pipelines
   - Standalone 
FileName: how-this-app-was-made
NoList: false
...

This post has been left intentionally empty.
